package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookcontrollerApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookcontrollerApplication.class, args);
	}

}
