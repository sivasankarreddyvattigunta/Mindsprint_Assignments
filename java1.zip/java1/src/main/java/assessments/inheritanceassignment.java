package assessments;

public class inheritanceassignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
