package assessments;

public class constructoroverloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
