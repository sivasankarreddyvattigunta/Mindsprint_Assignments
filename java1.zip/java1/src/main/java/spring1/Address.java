package spring1;

public class Address {
    private String city;
    public Address(String city) {
    	this.city=city;
    }
    public void t() {
    	System.out.println("city :"+city);		
    }
    
}
