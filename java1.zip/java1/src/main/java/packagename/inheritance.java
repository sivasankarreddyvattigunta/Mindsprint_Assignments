package packagename;

public class inheritance extends encapsulation {
    
	public static void main(String[] args) {
		inheritance i=new inheritance();
		i.display1();

	}

}
