package packagename;

public class constructor {

}
