package packagename;

public class constructor1 {
	int a,b;
      public constructor1(){
    	 a=45;
    	 b=10;
    	 
     }
	public static void main(String[] args) {
	
		constructor1 c=new constructor1();
		System.out.println(c.a*c.b);

	}

}
