package packagename;

public class static1 {
	int b;
	
	static String colour="red";
	public static1(){
		 b=10;
		 	 
	}
	static public void red() {
		
	}

	public static void main(String[] args) {
		static1 a=new static1();
     System.out.println(a.b);
     System.out.println(static1.colour);
	}

}
