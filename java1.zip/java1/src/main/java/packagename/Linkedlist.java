package packagename;

public class Linkedlist {

	public static void main(String[] args) {
		

	}

}
