package packagename;

public class javaclass {
	static public int Sum()  {
		int a=10;
		int b=20;
		int c= a+b;
		return c;
	}
	public int add() {
		int a=10;
		int b=25;
		return a+b;
	}
	

	public static void main(String[] args) {
		javaclass d=new javaclass();
		int f=d.add();
		System.out.println(f);
    int a=3;
    String name="Siva";
    boolean s=false;
    int c=Sum();
System.out.println(c);
	}
	

}

