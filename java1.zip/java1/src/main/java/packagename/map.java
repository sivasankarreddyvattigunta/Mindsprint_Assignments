package packagename;

import java.util.HashMap;

public class map {

	public static void main(String[] args) {
		HashMap n=new HashMap();
        n.
	}

}
